function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6b545fumNgF":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

