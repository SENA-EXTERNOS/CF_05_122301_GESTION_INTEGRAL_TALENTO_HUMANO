function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6NHoHQYhfBM":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

